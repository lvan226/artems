$(modal).removeClass('active');
$('.modal__overlay').detach();